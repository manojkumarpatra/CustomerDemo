package com.tel.customer.util;

import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class AuthorizationUtils {
	public void isAuthorized1(Map<String, String> headers) {
		String userName = headers.get(ApplicationConstant.USER_NAME);
		String password = headers.get(ApplicationConstant.PASSWORD);
		if ((userName == null || password == null)
				|| (!userName.equals("technical") && password.equals("Assessment"))) {
			throw new UnAuthorizedException(ApplicationConstant.UNAUTHORIZED);
		}
	}
	public void isAuthorized(String userName,String password) {
		
		if ((userName == null || password == null)
				|| (!userName.equals("technical") && password.equals("Assessment"))) {
			throw new UnAuthorizedException(ApplicationConstant.UNAUTHORIZED);
		}
	}
}
