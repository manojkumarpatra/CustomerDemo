package com.tel.customer.aop;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tel.customer.util.ApplicationConstant;
import com.tel.customer.util.AuthorizationUtils;

@Aspect
@Component
public class AuthorizeAspect {
	@Autowired
	AuthorizationUtils authorizationUtils;

@Before(" @annotation(com.tel.customer.aop.AuthPreProcess)")
  public void beforeAspect(HttpServletRequest request) throws Throwable {
	authorizationUtils.isAuthorized(request.getHeader(ApplicationConstant.USER_NAME),
			request.getHeader(ApplicationConstant.PASSWORD));
  }
}



