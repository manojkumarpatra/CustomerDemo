package com.tel.customer.util;

public interface ApplicationConstant {

	String CUSTOMER_NOT_FOUND = "Customer not Found";
	String INACTIVE_CUSTOMER = "Inactive Customer...";
	String UNAUTHORIZED = "Unauthorized access...";
	String USER_NAME = "username";
	String PASSWORD = "password";
}
